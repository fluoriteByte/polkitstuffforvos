/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if translation of program messages to the user's native
   language is requested. */
#define ENABLE_NLS 1

/* Notify us when we'll need to transition away from g_type_init() */
#define GLIB_VERSION_MAX_ALLOWED G_ENCODE_VERSION(2,34)

/* Avoid warning spew about g_type_init() being deprecated */
#define GLIB_VERSION_MIN_REQUIRED GLIB_VERSION_2_30

/* Define to 1 if you have the MacOS X function CFLocaleCopyCurrent in the
   CoreFoundation framework. */
/* #undef HAVE_CFLOCALECOPYCURRENT */

/* Define to 1 if you have the MacOS X function CFPreferencesCopyAppValue in
   the CoreFoundation framework. */
/* #undef HAVE_CFPREFERENCESCOPYAPPVALUE */

/* Define if the GNU dcgettext() function is already present or preinstalled.
   */
#define HAVE_DCGETTEXT 1

/* Define if the GNU gettext() function is already present or preinstalled. */
#define HAVE_GETTEXT 1

/* Define if you have the iconv() function and it works. */
/* #undef HAVE_ICONV */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "https://fedorahosted.org/polkit-pkla-compat/"

/* Define to the full name of this package. */
#define PACKAGE_NAME "polkit-pkla-compat"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "polkit-pkla-compat 0.1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "polkit-pkla-compat"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.1"

/* Number of bits in a file offset, on hosts where this is settable. */
/* #undef _FILE_OFFSET_BITS */

/* Define for large files, on AIX-style hosts. */
/* #undef _LARGE_FILES */
