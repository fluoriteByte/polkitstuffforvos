## Current behaviour, description of the problem
[State what seems to be the biggest issue here]: #


## Desired behaviour
[What polkit should do, but doesn't]: #


## Reproducer
[What are the steps to reproduce the issue. This will help us to find the root cause faster.]: #


## Detailed description
[Please try to be as descriptive, yet concise here]: #
[Version of polkit]: #
[Version of OS]: #
[Anything else related to the issue]: #
